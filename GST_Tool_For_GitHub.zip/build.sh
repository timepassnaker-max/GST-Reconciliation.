#!/bin/bash
# Build script for Render

# Create necessary directories
mkdir -p backend/temp

# Install dependencies
pip install -r requirements.txt
